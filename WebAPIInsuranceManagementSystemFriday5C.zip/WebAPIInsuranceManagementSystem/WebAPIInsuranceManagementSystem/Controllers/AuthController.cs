﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WebAPIInsuranceManagementSystem.Services.DTOs;
using WebAPIInsuranceManagementSystem.Services.Services.IServices;

namespace WebAPIInsuranceManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(UserDTO userBusinessModel)
        {
            try
            {

                int result = await _authService.Register(userBusinessModel);

                if (result == 1)
                {
                    return BadRequest("Email already exists.");
                }

                if (result == 2)
                {
                    return Ok("Registration successful");
                }
                else
                {
                    return BadRequest("Registration failed");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in Register action: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }


        

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDTO userLoginModel)
        {
            try
            {
     
                var token = await _authService.Login(userLoginModel.Email, userLoginModel.Password);

           
                if (token != null)
                {
                    Response.Headers.Add("Authorization",token);    
                    return Ok(new { token });
                }
                else
                {
                    return Unauthorized("Invalid username or password");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in Login action: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }
    }
}
