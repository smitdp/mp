create database InsuranceAndClaimManagementDB;
use InsuranceAndClaimManagementDB;

CREATE TABLE Roles (
    ID INT PRIMARY KEY IDENTITY,
    RoleName VARCHAR(50) NOT NULL
);


CREATE TABLE Users (
    ID INT PRIMARY KEY IDENTITY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    PhoneNumber VARCHAR(20),
    RoleId INT FOREIGN KEY REFERENCES Roles(ID) NOT NULL,
    IsApproved INT,
    IsActive BIT NOT NULL
);


CREATE TABLE PolicyTypes (
    ID INT PRIMARY KEY IDENTITY,
    PolicyTypeName VARCHAR(100) NOT NULL
);


CREATE TABLE Policies (
    ID INT PRIMARY KEY IDENTITY,
    PolicyNumber VARCHAR(50) NOT NULL,
    PolicyTypeID INT FOREIGN KEY REFERENCES PolicyTypes(ID) NOT NULL,
    PolicyName VARCHAR(100),
    Duration INT,
    Description VARCHAR(MAX),
    Installment DECIMAL(18,2),
    PremiumAmount DECIMAL(18,2),
    IsActive BIT NOT NULL
);


CREATE TABLE DocumentList (
    ID INT PRIMARY KEY IDENTITY,
    PolicyId INT FOREIGN KEY REFERENCES Policies(ID) NOT NULL,
    DocumentType VARCHAR(100) NOT NULL
);


CREATE TABLE UserPolicy (
    ID INT PRIMARY KEY IDENTITY,
    UserId INT FOREIGN KEY REFERENCES Users(ID) NOT NULL,
    PolicyId INT FOREIGN KEY REFERENCES Policies(ID) NOT NULL,
	AgentId INT FOREIGN KEY REFERENCES Users(ID) NOT NULL,
    EnrollmentDate DATE NOT NULL,
    EndDate DATE
);


CREATE TABLE Claims (
    ID INT PRIMARY KEY IDENTITY,
    PolicyId INT FOREIGN KEY REFERENCES Policies(ID) NOT NULL,
    UserId INT FOREIGN KEY REFERENCES Users(ID) NOT NULL,
    IncidentDate DATE NOT NULL,
    IncidentLocation VARCHAR(100),
    Address VARCHAR(255),
    Description VARCHAR(MAX),
    Status INT 
);

--1 for Pending
--2 for Under Review
--3 for Approved
--4 for Denied
--5 for Processing
--6 for Done
--7 for Closed



CREATE TABLE ClaimDocuments (
    ID INT PRIMARY KEY IDENTITY,
    ClaimId INT FOREIGN KEY REFERENCES Claims(ID) NOT NULL,
    DocumentPath VARCHAR(255) NOT NULL
);


CREATE TABLE AuditLogs (
    ID INT PRIMARY KEY IDENTITY,
    UserId INT FOREIGN KEY REFERENCES Users(ID) NOT NULL,
    Timestamp DATETIME NOT NULL,
    Action VARCHAR(100) NOT NULL,
    Category VARCHAR(100), 
    Details VARCHAR(MAX),
    IsSuccess BIT
);


INSERT INTO Roles (RoleName)
VALUES ('Insurer'), ('Agent'), ('Claimant');

INSERT INTO Users (FirstName, LastName, Password, Email, PhoneNumber, RoleId, IsApproved, IsActive)
VALUES ('Admin', 'Admin', 'adminpassword', 'admin@example.com', '1234567890', 1, 1, 1);

INSERT INTO PolicyTypes (PolicyTypeName)
VALUES ('Health'), ('Life'), ('Automobile'), ('Home'), ('Travel');


INSERT INTO Policies (PolicyNumber, PolicyTypeID, PolicyName, Duration, Description, Installment, PremiumAmount, IsActive)
VALUES 
-- Health Policies
('HEA001', 1, 'HealthGuard Plus', 365, 'Comprehensive health insurance for individuals.', 1500 , 100000, 1),
('HEA002', 1, 'Wellness Shield', 365, 'Health insurance policy with comprehensive coverage.', 1250, 90000, 1),

-- Life Policies
('LIF001', 2, 'LifeSure Protector', 730, 'Term life insurance policy for up to 2 years.', 2100,300000 , 1),
('LIF002', 2, 'EternalLife Assurance', 1095, 'Whole life insurance policy with lifetime coverage.', 4000, 1000000, 1),

-- Automobile Policies
('AUT001', 3, 'AutoShield Comprehensive', 365, 'Comprehensive insurance coverage for automobiles.', 2000, 150000, 1),
('AUT002', 3, 'DriveSafe Liability Coverage', 365, 'Third-party liability insurance for automobiles.', 3000, 300000, 1),

-- Home Policies
('HOM001', 4, 'HomeSafe Property Insurance', 365, 'Home insurance policy covering property and belongings.', 4500, 500000, 1),
('HOM002', 4, 'RentGuard Tenant Insurance', 365, 'Renter insurance policy for tenants.', 5500, 700000, 1),

-- Travel Policies
('TRA001', 5, 'TravelCare Protection', 7, 'Travel insurance policy for short-term trips.', 999, 100000, 1),
('TRA002', 5, 'GlobalGuard Medical Coverage', 15, 'International travel insurance policy with medical coverage.', 1499, 500000, 1)




select * from Roles;
select * from Users;
select * from PolicyTypes;
select * from Policies;
