import React from 'react'
import MouseEffect from '../MouseEffect/MouseEffect'

const SureBot = () => {
  return (
      <div>
        <MouseEffect />

    </div>
  )
}

export default SureBot