import { Routes, Route } from "react-router-dom";
import Policies from "./components/Policies/Policies";
import PolicyDetails from "./components/policyDetails/PolicyDetails";
import Login from "./components/Login/Login";
import AuthService from "./services/AuthService";
import MyPolicies from "./components/MyPolicies/MyPolicies";
import LoginProvider from "./context/LoginContext";
import UserInformationProvider from "./context/UserInformationContext";
import RegisterPage from "./Pages/RegisterPage";
import ClaimForm from "./components/ClaimForm/ClaimForm";
import AppLayout from "./Pages/AppLayout";

function App() {
  const isAuthenticated = AuthService.isAuthenticated();
  //new comment
  return (
    <div>
    
          <Routes>
            <Route path="/" element={<AppLayout />} />
            <Route path="/login" element={<Login />} />
            <Route path = "/register" element={<RegisterPage /> }/>
            <Route path="/policies" element={<Policies />} />
            <Route path="/policy" element={<PolicyDetails />} />
            <Route path="/my-policies" element={<MyPolicies />} />
            <Route path="/claim" element={<ClaimForm />} />
          </Routes>
   
    </div>
  );
}

export default App;
