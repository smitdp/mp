import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { baseURL } from "../../Server";
import axios from "axios";
import getCurrentUserId from "../../utils/getCurrentUserId";
import { Navigate, useNavigate } from 'react-router-dom'; 

const MyPolicies = () => {
  const [myPolicies, setMyPolicies] = useState([]);
  const userId = getCurrentUserId();
  const navigate = useNavigate(); 

  useEffect(() => {
    const fetchPolicies = async () => {
      try {
        const response = await axios.get(`${baseURL}/user/my-policies/${userId}`);
        setMyPolicies(response.data);
      } catch (error) {
        console.log(error.message);
      }
    };

    fetchPolicies();
  }, []);

  const handleClaimClick = (policy) => {
    console.log(policy);
    navigate("/claim", { state: { policy: policy } }); // Use navigate function to navigate to the claim route
  };

  return (
    <div>
      <h1>My Policies</h1>
      <ul>
        {myPolicies.map((policy) => (
          <li key={policy.id}>
            <h3>{policy.policyName}</h3>
            <p>Type: {policy.policyTypeName}</p>
            <button disabled={policy.isClaimed} onClick={() => handleClaimClick(policy)}>Claim</button>

          </li>
        ))}
      </ul>
    </div>
  );
};

export default MyPolicies;
