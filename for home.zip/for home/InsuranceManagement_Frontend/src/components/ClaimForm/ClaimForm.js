import React, { useState } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import { baseURL } from '../../Server';

const ClaimForm = () => {
    const Location = useLocation();
    const policyDetails = Location.state.policy;
    const [formData, setFormData] = useState({
        policyId: policyDetails.policyId,
        userId: policyDetails.userId,
        incidentDate: '',
        incidentLocation: '',
        address: '',
        description: '',
        status: 1,
        documents: [Array(policyDetails.documentsNeeded.length).fill(null)],
    });

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        console.log(formData);
    };

    const handleFileChange = (e, index) => {
        const newFiles = [...formData.documents];
        newFiles[index] = "D:/Major project Data/" + e.target.files[0].name;
        setFormData({ ...formData, documents: newFiles });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(formData);
        
        try {
            const response = await axios.post(`${baseURL}/claim/claims`, formData);
        } catch(error) {
            alert("Something went wrong");
        }
    };

    return (
        <div>
            <h2>Claim Form</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Incident Date:</label>
                    <input type="date" name="incidentDate" value={formData.incidentDate} onChange={handleInputChange} />
                </div>
                <div>
                    <label>Incident Location:</label>
                    <input type="text" name="incidentLocation" value={formData.incidentLocation} onChange={handleInputChange} />
                </div>
                <div>
                    <label>Address:</label>
                    <input type="text" name="address" value={formData.address} onChange={handleInputChange} />
                </div>
                <div>
                    <label>Description:</label>
                    <textarea name="description" value={formData.description} onChange={handleInputChange} />
                </div>
                {policyDetails.documentsNeeded.map((document, index) => (
                    <div key={index}>
                        <label>{document}:</label>
                        <input type="file" onChange={(e) => handleFileChange(e, index)} />
                    </div>
                ))}
                <button type="submit">Submit Claim</button>
            </form>
        </div>
    );
};

export default ClaimForm;
